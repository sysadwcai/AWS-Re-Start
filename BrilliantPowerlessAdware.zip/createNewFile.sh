#! /bin/bash
for i in $(seq 25)
do
  touch file-${i}.txt
  sleep 1
done


find_newest_file_matching_pattern_under_directory(){
    echo $(find $1 -name $2 -print0 | xargs -0 ls -1 -t | head -1)
}

#invoke the function:
newest_file=$( find_newest_file_matching_pattern_under_directory /home/runner/BrilliantPowerlessAdware/ file* )
echo $newest_file
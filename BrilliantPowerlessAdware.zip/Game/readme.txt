Welcome to Winnie's Resturant!

The objective for this level is select a dish and help the chef to gather ingredents for the dish.

Oh no, the sous-chef is out to search for the ubiqitous magic ingredents, now you are the sous-chef, gather up th 5 ingredents for chef to make your meal.

Select 5 ingredents in alphabetical order from the ingredents list

If you are a good sous-chef, you should know the ingredents by heart and knowing Linux is essential. If you are new to the job, the answer in somewhere in hotel where the file name is rhym with fireball.
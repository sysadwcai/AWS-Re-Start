#! /bin/bash

file="./output.txt"


while read -r line
do  
    #if [[ ! $line =~ ^[0-9] ]] #names don't start with numbers
    #then 
     #   echo $line >> out.txt
    #fi

    #if [[ $line =~ ^[a-zA-Z] ]] #start with letter
    #then 
      #  echo "Start with letters:  $line">> out.txt
   # fi

    if [[ $line =~ [0-9]$ ]] #end with numbers
    then 
        echo "End with numbers: $line">> out.txt
    fi

    #if [[ $line =~ ^[0-9] ]] #start with numbers
    #then 
      #  echo "End with numbers: $line">> out.txt
    #fi 

   # if [[ $line =~ [@] ]] #contains @ sign
   # then 
      #  echo "Contains @ sign: $line"
   # fi

done < $file